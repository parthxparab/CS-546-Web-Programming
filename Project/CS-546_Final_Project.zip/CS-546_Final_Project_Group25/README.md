# CS546-Final-Project
Group Members: Zachary Zwerling, Parth Parab, Dharika Kapil, Neil Gupte

Dependencies used: Express, MongoDB, XSS, Ajax, Handlebars, BCrypt, Node, Jquery, 
API: Google Charts, Semantic UI

MongoDB Collections: Manager (Storing Manager Details) , Employee (Storing Employee Details) , Transaction (Logging Activities in application) , Help (Tickets from Employee), Users (User Login and Hashed Passwords)

How to RUN: run app.js or npm start


