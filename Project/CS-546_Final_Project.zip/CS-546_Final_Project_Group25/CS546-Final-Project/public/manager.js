function showTickets(){
    document.getElementById("ticketList").style.display = "block"
}